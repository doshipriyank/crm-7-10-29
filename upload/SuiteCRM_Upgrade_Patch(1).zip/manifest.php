<?php 
$manifest = array(
   'name' => 'Suitecrm Upgrade Patch',
   'description' => 'This package will patch the upgrade wizard',
   'author' => 'SalesAgility Ltd',
   'version' => '1.0',
   'published_date' => '2020-06-10',
   'type' => 'module',
   'is_uninstallable' => false,
 );

 $installdefs = array(
   'id' => 'suitecrm_upgrade_patch',
   'copy' => array(
     array(
       'from' => '<basepath>/UpgradeWizard/cancel.php',
       'to' => 'modules/UpgradeWizard/cancel.php',
     ),
     array(
      'from' => '<basepath>/UpgradeWizard/commit.php',
      'to' => 'modules/UpgradeWizard/commit.php',
    ),
    array(
      'from' => '<basepath>/UpgradeWizard/index.php',
      'to' => 'modules/UpgradeWizard/index.php',
    ),
    array(
      'from' => '<basepath>/UpgradeWizard/preflight.php',
      'to' => 'modules/UpgradeWizard/preflight.php',
    ),
    array(
      'from' => '<basepath>/UpgradeWizard/systemCheck.php',
      'to' => 'modules/UpgradeWizard/systemCheck.php',
    ),
    array(
      'from' => '<basepath>/UpgradeWizard/UploadFileCheck.php',
      'to' => 'modules/UpgradeWizard/UploadFileCheck.php',
    ), 
   ),
 );
